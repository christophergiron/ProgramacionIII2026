﻿using Clase10.API.Endpoints;
using Dapper;
using Npgsql;
namespace Clase10.Infrastructure;

public class PostgresProductRepository : IProductRepository
{
    private readonly IConfiguration _configuration;
    private readonly string _connectionString;

    public PostgresProductRepository(IConfiguration configuration)
    {
        _configuration = configuration;
        _connectionString = _configuration.GetConnectionString("Postgres")!;
    }

    private NpgsqlConnection CreateConnection()
    {
        return new NpgsqlConnection(_connectionString);
    }

    public async Task<List<ProductDto>> GetAll()
    {
        using var connection = CreateConnection();

        var sql = @"
            SELECT
                id,
                name,
                description,
                price,
                stock
            FROM products
            ORDER BY name;
        ";

        var result = await connection.QueryAsync<ProductDto>(sql);

        return result.ToList();
    }

    public async Task<ProductDto> Get(string id)
    {
        using var connection = CreateConnection();

        var sql = @"
            SELECT
                id,
                name,
                description,
                price,
                stock
            FROM products
}